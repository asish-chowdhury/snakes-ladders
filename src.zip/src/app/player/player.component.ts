import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrl: './player.component.scss'
})
export class PlayerComponent {
  @Input() player!: Player;
  playerColors: string[] = ['red', 'blue', 'green', 'yellow'];

  getPlayerColor(): string {
    return this.playerColors[this.player.id - 1]; // Default to 'aqua' if no color is found
  }
}

interface Player {
  id: number;
  position: number;
}
