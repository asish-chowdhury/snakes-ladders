import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrl: './board.component.scss'
})
export class BoardComponent implements OnInit {
  players: Player[] = [];
  currentPlayerIndex: number = 0;
  diceValue: number = 1;

  ngOnInit() {
    // Initialize players
    for (let i = 1; i <= 4; i++) {
      this.players.push({ id: i, position: 1 });
    }
  }
  handleSnakesAndLadders(position: number): number {
    // Implement your snakes and ladders logic here
    // For simplicity, let's assume there are no snakes and ladders in this example
    return position;
  }
  boardCells(): number[] {
    // Generate an array of numbers from 1 to 100 for the board cells
    return Array.from({ length: 100 }, (_, i) => i + 1);
  }

  isPlayerInCell(cell: number): boolean {
    // Check if any player is in the given cell
    return this.players.some(player => player.position === cell);
  }

  resetGame() {
    // Reset player positions
    this.players.forEach(player => player.position = 1);
    this.currentPlayerIndex = 0;
  }

  getPlayerInCell(cell: number): Player {
    return this.players.find(player => player.position === cell) || { id: 0, position: 0 };
  }

  isGameOver(): boolean {
    // Check if the game is over
    return this.players.some(player => player.position >= 100);
  }

  rollingDice: boolean = false;
  rollDice() {
    if (!this.rollingDice) {
      this.rollingDice = true;
      setTimeout(() => {
        this.diceValue = Math.floor(Math.random() * 6) + 1;
        this.rollingDice = false;
      }, 1000);

      const currentPlayer = this.players[this.currentPlayerIndex];
      currentPlayer.position += this.diceValue;

      // Handle snakes and ladders
      currentPlayer.position = this.handleSnakesAndLadders(currentPlayer.position);

      // Check for a winner
      if (currentPlayer.position >= 100) {
        alert(`Player ${currentPlayer.id} wins!`);
        this.resetGame();
        return;
      }
      // Switch to the next player
      this.currentPlayerIndex = (this.currentPlayerIndex + 1) % this.players.length;
    }
  }
}

interface Player {
  id: number;
  position: number;
}